package interfaces;


import java.util.Comparator;


public class followerComperator implements Comparator<TwitterAccount> {

	public followerComperator(Comparator<TwitterAccount> o1) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(TwitterAccount o1, TwitterAccount o2) {
		// TODO Auto-generated method stub
		return 0;
	}



}
