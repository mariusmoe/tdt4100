package objektstrukturer;

import java.util.Scanner;
import java.util.Arrays;

public class SudokuProgram {
	
	String[][] SGame = new String[9][9];
	
	String brett;
	
	void init(String s){
		//lag en string builder av "base" stringen
		this.brett = s;

	}
	
	SudokuBoard sudokuBoard = new SudokuBoard();
			
	void run(){
	
		Scanner scanner = new Scanner(System.in);
		
		
		SudokuCheck sudokuCheck = new SudokuCheck();
		sudokuBoard.printOutBoardString(brett);
		System.out.println("f.eks: 0,a:3");
		this.SGame = sudokuBoard.Slist;
		
	 while (true) {

		 System.out.print(" > ");
         String token = scanner.nextLine();  // declare and initialise the token variable
     	
         String string = token;
         String[]  parts = string.split("\\,|\\:");
			String part1 = parts[0]; // x rettning	--> disse ble snudd?\
			String part2 = parts[1]; // y rettning
			String part3 = parts[2]; // ønsket endring
			
			System.out.println(part1+" : "+ part2+" : "+ part3);

         if (sudokuCheck.isValidInput(parts)){
        	 
        	 if (sudokuCheck.cellIsBusy(part1, part2, part3, brett)){
        		 System.err.println("Du prøvde å endre betingelsene for oppgaven :(");
        	 }
        	 else{
        		 if (sudokuCheck.rcConflict(part1, part2, part3, SGame) || sudokuCheck.conflict3x3(part1, part2, part3, SGame)){
            		 this.SGame[Arrays.asList(sudokuBoard.letter).indexOf(part2)][Integer.valueOf(part1)] = part3 + "*"; 
        		 }
        		 else{
        			 this.SGame[Arrays.asList(sudokuBoard.letter).indexOf(part2)][Integer.valueOf(part1)] = part3;
        		 	}
        		 sudokuBoard.drawBoard(SGame);
        	 }
         }
         else if (token.equals("exit")){
         	break;
         }
         else{
        	 System.err.println("input var ikke gyldig");
         }
     }
     System.out.println("program exited");
     scanner.close();
 }
	
	public static void main(String[] args) {
		SudokuProgram sudokuProgram = new SudokuProgram();
		sudokuProgram.init(".68.257.3..........71..39..61.35.2...8.....4...3.64.95..76..58..........8.653.42.");
		sudokuProgram.run();	
	}
}