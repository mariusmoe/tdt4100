package patterns.observable;

public interface HighscoreListListener {
	void listChanged(HighscoreList l, int i);
}
