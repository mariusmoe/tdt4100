package patterns;

public interface StockListener {
	
	void stockPriceChanged(Stock st, double d, double d2);

}
